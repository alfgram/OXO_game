package OXOExceptions;

public class CellDoesNotExistException extends OXOMoveException
{

}
