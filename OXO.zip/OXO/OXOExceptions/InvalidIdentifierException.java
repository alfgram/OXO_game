package OXOExceptions;

public class InvalidIdentifierException extends CellDoesNotExistException
{

}
